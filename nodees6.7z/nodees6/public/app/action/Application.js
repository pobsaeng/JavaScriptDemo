function createTagIntoBody() {
    let dom = new Dom();
    let header = dom.createTag('div', { id: 'page-header' }),
        content = dom.createTag('div', { id: 'page-content' }),
        footer = dom.createTag('div', { id: 'page-footer' });

    document.body.appendChild(header);
    document.body.appendChild(content);
    document.body.appendChild(footer);
}
let tpl = new Template();
function changeHTMLPage(page, path) {
    switch (page) {
        case "Home":
            tpl.changeHtmlPage(path, function (status) { if (status) new Home(); });
            break;

        case "Table":
            tpl.changeHtmlPage(path, function (status) { if (status) new CreateTable(); });
            break;

        case "WebStorage":
            tpl.changeHtmlPage(path, function (status) { if (status) new WebStorageDemo(); });
            break;
    }
}
window.onload = function () {
    createTagIntoBody();
    tpl.afterRenderIndexHTML('html/webstorage/webstorage.html', function (bool) {
        if (bool) {
            new WebStorageDemo();
        }
    });
};

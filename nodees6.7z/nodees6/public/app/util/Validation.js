class Validation {
    trim(str) {
        return str.replace(/^\s+|\s+$/g, '');
    }
    checkNumber(str) {
        let vOver = '';
        while (str.length > 0 && isNaN(str)) {
            str = str.substring(0, str.length - 1);
            //vOver = (str.length - 1, str.length);
        }
        return this.trim(str);
    }
}
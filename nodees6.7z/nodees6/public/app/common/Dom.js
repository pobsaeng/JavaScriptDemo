class Dom {
    constructor() { }
    createTag(name, attributes) {
        let node = document.createElement(name);
        if (attributes) {
            for (let attr in attributes) {
                if (attributes.hasOwnProperty(attr)) {
                    node.setAttribute(attr, attributes[attr]);
                }
            }
        }

        for (let i = 2; i < arguments.length; i++) {
            let child = arguments[i];
            if (typeof child == "string") {
                child = document.createTextNode(child);
                node.appendChild(child);
            }
        }
        return node;
    }
    getArrayAttributeId(domEl) {
        let arrList = [];
        let childdren = this.validateDom(domEl).childNodes;

        for (let i = 0; i < childdren.length; i++) {
            if (childdren[i].nodeType == 1) {
                this.getArrayAttributeList(childdren[i], arrList);
            }
        }
        return arrList;
    }
    getArrayAttributeList(domEl, array) {
        //user => let arrayId = dom.getArrayAttributeId('id');
        let childdren = domEl.childNodes;
        for (let i = 0; i < childdren.length; i++) {
            if (childdren[i].nodeType == 1 && childdren[i].id != '') {
                array.push(childdren[i].id);
            }
        }
    }
    getNodeByAttribute(domEl, att) {
        //<= user => 
        // var attr = dom.getNodeByAttribute(domEl);
        // if (attr != undefined) { domEl = document.getElementById(attr.nodeValue) }
        let attrs = domEl.attributes;
        for (let i = 0; i < attrs.length; i++) {
            if (typeof (attrs[i]) != 'undefined' && attrs[i] != null) {
                if (typeof att != 'undefined') {
                    if (attrs[i].nodeName == att) {
                        return attrs[i];
                    }
                } else {
                    if (attrs[i].nodeName == 'id' || attrs[i].nodeName == 'name') {
                        return attrs[i];
                    }
                }
            }
        }
    }
    toggleVisibility(domEl) {
        domEl = this.validateDom(domEl);
        if (domEl.style.display == 'block') {
            domEl.style.display = 'none';
        } else {
            domEl.style.display = 'none';
        }
    }
    validateDom(domEl) {
        if (typeof domEl === "string" && domEl != null) {
            domEl = document.getElementById(domEl);
        }
        return domEl;
    }
    removeHtml(html) {
        let tmp = document.implementation.createHTMLDocument("New").body;
        tmp.innerHTML = html;
        return tmp.textContent || tmp.innerText || "";
    }
    removeChildDomEl(domEl) {
        var element = this.validateDom(domEl);
        for (var i = element.length - 1; i >= 0; i--) {
            if (element[i]) { element[i].parentNode.removeChild(element[i]); }
        }
    }
}